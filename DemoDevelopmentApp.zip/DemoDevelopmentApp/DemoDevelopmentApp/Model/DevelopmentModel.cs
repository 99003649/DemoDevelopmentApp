﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoDevelopmentApp.Model
{
    public class DevelopmentModel
    {
        private string _name;
        public string ExeName
        {
            get { return _name; }
            set { _name = value; }
        }
        public class ConfigurationSettings
        {
            public List<string> File1 = new List<string>(ConfigurationManager.AppSettings["File"].Split(new char[] { ',' }));
        }
    }
}
