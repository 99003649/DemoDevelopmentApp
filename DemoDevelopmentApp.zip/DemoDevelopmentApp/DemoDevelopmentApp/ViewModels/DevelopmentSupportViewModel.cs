﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using System.Windows;
using System.Threading;
using System.ComponentModel;
using System.Collections.ObjectModel;
using DemoDevelopmentApp.Model;
using System.Windows.Threading;
using System.IO;

namespace DemoDevelopmentApp.ViewModels
{
    public class DevelopmentSupportViewModel : INotifyPropertyChanged
    {
        private Command _killProcess;
        public Command mKillProcess
        {
            get { return _killProcess; }
            set { _killProcess = value; }
        }
        private Command _replaceFile;
        public Command _ReplaceFile
        {
            get { return _replaceFile; }
            set { _replaceFile = value; }
        }
        private Command _clearCahce;
        public Command _ClearCache
        {
            get { return _clearCahce; }
            set { _clearCahce = value; }
        }
        private Command _pdvCache;
        public Command _PDVCache
        {
            get { return _pdvCache; }
            set { _pdvCache = value; }
        }
        private Command _OpenFileSource;
        public Command OpenFile
        {
            get { return _OpenFileSource; }
            set { _OpenFileSource = value; }
        }

        private Command _OpenFileDestination;
        public Command OpenFile1
        {
            get { return _OpenFileDestination; }
            set { _OpenFileDestination = value; }
        }

        private string _tbxFiles;
        public string tbxFileSource
        {
            get { return _tbxFiles; }
            set
            { 
                _tbxFiles = value;
                PropertyChanged(this, new PropertyChangedEventArgs("tbxFiles"));
            }
        }
        private string _tbxFiles1;
        public string tbxFileDest
        {
            get { return _tbxFiles1; }
            set 
            { 
                _tbxFiles1 = value;
                PropertyChanged(this, new PropertyChangedEventArgs("tbxFiles1"));
            }
        }
        private ObservableCollection<DevelopmentModel> _file;
        public ObservableCollection<DevelopmentModel> File
        {
            get { return _file; }
            set { _file = value; }
        }
        public ObservableCollection<string> Listname = new ObservableCollection<string>();
        public DevelopmentSupportViewModel()
        {
            _killProcess = new Command(null, KillProcess);
            _replaceFile = new Command(null, ReplaceFile);
            _clearCahce = new Command(null, ClearCache);
            _pdvCache = new Command(null, PDVCache);
            _OpenFileSource = new Command(null, OpenFileSource);
            _OpenFileDestination = new Command(null, OpenFileDestination);
            File = new ObservableCollection<DevelopmentModel>()
            {
                new DevelopmentModel(){ExeName = "Calculator"},
                new DevelopmentModel(){ExeName = "notepad"},
                new DevelopmentModel(){ExeName = "chrome"},
                new DevelopmentModel(){ExeName = "msedge"},
                new DevelopmentModel(){ExeName = "cmd"}
            };
        }
        public event PropertyChangedEventHandler PropertyChanged = delegate { };
        private int mCounter;
        public double Counter
        {
            get { return mCounter; }
            set
            {
                mCounter = (int)value;
                PropertyChanged(this, new PropertyChangedEventArgs("Counter"));
            }
        }
        //Progress Bar Kill Process
        public void ProgressBar()
        {
            if(number > 0)
            {
                for (int i = 1; i <= Listname.Count; i++)
                {
                    Application.Current.Dispatcher.Invoke(
                            DispatcherPriority.Background,
                            (Action)(() =>
                            {
                                Counter = i * 100 / Listname.Count;
                                Thread.Sleep(200);
                            }));
                }
            }
        }
        //Common Progress Bar
        public void CommonProgressBar()
        {
            for (int i = 1; i <= number; i++)
            {
                Application.Current.Dispatcher.Invoke(
                        DispatcherPriority.Background,
                        (Action)(() =>
                        {
                            Counter = i * 100 / number;
                            Thread.Sleep(200);
                        }));
            }
        }
        //Kill Process
        public void KillProcess(object sender)
        {
            number = 0;
            int x;
            DevelopmentModel.ConfigurationSettings ObjConfig = new DevelopmentModel.ConfigurationSettings();
            Listname = new ObservableCollection<string>();
            for(int c = 0; c < ObjConfig.File1.Count; c++)
            {
                Listname.Add(ObjConfig.File1[c]);
            }
            for (x = 0; x < ObjConfig.File1.Count; x++)
            {
                foreach (Process Proc in Process.GetProcesses())
                {
                    if (x >= ObjConfig.File1.Count)
                    {
                        continue;
                    }
                    else if (Proc.ProcessName.Equals(Listname[x]))
                    {
                        Proc.Kill();
                        number++;
                    }
                }
            }
            ProgressBar();
        }
        //Replace files
        public int number = 0;
        public void ReplaceFile(object sender)
        {
            number = 0;
            try
            {
                string SourceFile = tbxFileSource;
                string DestFile = tbxFileDest;
                DirectoryInfo Sourcedir = new DirectoryInfo(SourceFile);
                DirectoryInfo Destdir = new DirectoryInfo(DestFile);

                IEnumerable<FileInfo> list1 = Sourcedir.GetFiles("*.*");
                IEnumerable<FileInfo> list2 = Destdir.GetFiles("*.*");

                bool IsInDestination = false;

                foreach (FileInfo s in list1)
                {
                    IsInDestination = true;
                    foreach (FileInfo s2 in list2)
                    {
                        if (s.Name == s2.Name)
                        {
                            IsInDestination = true;
                            break;
                        }
                        else
                        {
                            IsInDestination = false;
                        }
                    }
                    if (IsInDestination)
                    {
                        System.IO.File.Copy(s.FullName, Path.Combine(DestFile, s.Name), true);
                        number++;
                    }
                }
                if (number > 1)
                {
                    CommonProgressBar();
                    MessageBoxResult result = MessageBox.Show(number + " Files Replaced Successfully!!!", "Confirmation");
                }
                else if (number == 1)
                {
                    CommonProgressBar();
                    MessageBoxResult result = MessageBox.Show(number + " File Replaced Successfully!!!", "Confirmation");
                }
                else
                {
                    MessageBoxResult result = MessageBox.Show(" No File Replaced", "Confirmation");
                }
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message +" Or Source and Destination can't be Empty", "Warning");
            }
        }
        //Clear Cache Nuget Package
        public void ClearCache(object sender)
        {
            number = 0;
            //search for .Nuget Folder
            DirectoryInfo di = new DirectoryInfo("C:\\Users");
            string Nuget = "";
            foreach (DirectoryInfo dir in di.EnumerateDirectories())
            {
                List<DirectoryInfo> Folder = new List<DirectoryInfo>();
                try
                {
                    IEnumerable<DirectoryInfo> Folderlist = dir.EnumerateDirectories();
                    foreach (DirectoryInfo s in Folderlist)
                    {
                        if (s.Name == ".nuget")
                        {
                            Nuget = s.FullName + "\\packages";
                        }
                    }
                }
                catch (Exception)
                {
                    continue;
                }
            }
            try
            {
                DirectoryInfo dirctory = new DirectoryInfo(Nuget);
                foreach (DirectoryInfo dir in dirctory.EnumerateDirectories())
                {
                    List<DirectoryInfo> FolderName = new List<DirectoryInfo>();
                    IEnumerable<DirectoryInfo> list1 = dir.EnumerateDirectories();
                    foreach (DirectoryInfo s in list1)
                    {
                        FolderName.Add(s);
                    }
                    if (FolderName.Count > 1)
                    {
                        if (FolderName[0].CreationTime > FolderName[1].CreationTime)
                        {
                            FolderName[1].Delete(true);
                            number++;
                        }
                        else if (FolderName[0].CreationTime < FolderName[1].CreationTime)
                        {
                            FolderName[0].Delete(true);
                            number++;
                        }
                        // remove this later 
                        if (number > 1)
                        {
                            break;
                        }
                    }
                    else
                    {
                        continue;
                    }
                }
                if (number >= 1)
                {
                    CommonProgressBar();
                    MessageBoxResult result = MessageBox.Show(number + " Old File Deleted Successfully!!!", "Confirmation");
                }
                else
                {
                    MessageBoxResult result = MessageBox.Show(" No Old File Found", "Confirmation");
                }
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message, "Warning");
            }
        }
        //PDV Cache
        public void PDVCache(object sender)
        {
            number = 0;
            string SourceFile = tbxFileSource;
            try
            {
                List<string> Folder = new List<string>();
                List<DirectoryInfo> FolderName = new List<DirectoryInfo>();
                DirectoryInfo Sourcedir = new DirectoryInfo(SourceFile);
                foreach (DirectoryInfo dir in Sourcedir.EnumerateDirectories())
                {
                    IEnumerable<DirectoryInfo> list1 = dir.EnumerateDirectories();
                    string FName = dir.Name;
                    string[] FNameList = FName.Split('.');
                    string NewFName = "";
                    for (int FN = 0; FN < FNameList.Length; FN++)
                    {
                        byte[] res = Encoding.ASCII.GetBytes(FNameList[FN].Substring(0, 1));

                        if ( (res[0] >= Convert.ToByte(65) && res[0] <= Convert.ToByte(90)) 
                            || (res[0] >= Convert.ToByte(97) && res[0] <= Convert.ToByte(122)))
                        {
                            NewFName += FNameList[FN];
                        }
                    }
                    Folder.Add(NewFName);
                    FolderName.Add(dir);
                }
                for (int FLen = 0; FLen < Folder.Count; FLen++)
                {
                    for (int CLen = 1; CLen < Folder.Count; CLen++)
                    {
                        if (Folder[FLen] == Folder[CLen])
                        {
                            if (FolderName[FLen].CreationTime > FolderName[CLen].CreationTime)
                            {
                                FolderName[CLen].Delete(true);
                                FolderName.Remove(FolderName[CLen]);
                                Folder.Remove(Folder[CLen]);
                                number++;
                                CLen--;
                            }
                            else if (FolderName[FLen].CreationTime < FolderName[CLen].CreationTime)
                            {
                                FolderName[FLen].Delete(true);
                                FolderName.Remove(FolderName[FLen]);
                                Folder.Remove(Folder[FLen]);
                                number++;
                                CLen--;
                            }
                        } 
                    } 
                }
                if (number >= 1)
                {
                    CommonProgressBar();
                    MessageBoxResult result = MessageBox.Show(number + " Old File Deleted Successfully!!!", "Confirmation");
                }
                else
                {
                    MessageBoxResult result = MessageBox.Show(" No Old File Found", "Confirmation");
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message + " Or Soucre can't be Empty", "Warning");
            }
        }
        //open file explorer
        public void OpenFileSource(object sender)
        {
            System.Windows.Forms.FolderBrowserDialog openFolderDialog = new System.Windows.Forms.FolderBrowserDialog();
            if (openFolderDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                tbxFileSource = openFolderDialog.SelectedPath;
            }
        }
        public void OpenFileDestination(object sender)
        {
            System.Windows.Forms.FolderBrowserDialog openFolderDialog = new System.Windows.Forms.FolderBrowserDialog();
            if (openFolderDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                tbxFileDest = openFolderDialog.SelectedPath;
            }
        }      
    }
}