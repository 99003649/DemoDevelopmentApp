﻿using System;
using System.Windows.Input;

namespace DemoDevelopmentApp.ViewModels
{
    public class Command : ICommand
    {
        public event EventHandler CanExecuteChanged;
        readonly Predicate<object> _canExecute;
        readonly Action<object> _execute;
        public bool CanExecute(object parameter)
        {
            return _canExecute == null || _canExecute(parameter);
        }
        public void Execute(object parameter)
        {
            _execute(parameter);
        }
        public Command(Predicate<object> canExecute, Action<object> execute)
        {
            if (execute == null)
                throw new ArgumentNullException("execute");
            _canExecute = canExecute;
            _execute = execute;
        }
        public static implicit operator Command(string v)
        {
            throw new NotImplementedException();
        }
    }
}