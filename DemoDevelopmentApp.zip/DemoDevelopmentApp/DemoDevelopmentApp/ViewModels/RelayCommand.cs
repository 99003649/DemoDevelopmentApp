﻿using System;
using System.Windows.Input;

namespace DemoDevelopmentApp.ViewModels
{
    internal class RelayCommand : ICommand
    {
        private Action<object> p1;
        private Func<object, bool> p2;

        public RelayCommand(Action<object> p1, Func<object, bool> p2)
        {
            this.p1 = p1;
            this.p2 = p2;
        }

        public event EventHandler CanExecuteChanged;

        public bool CanExecute(object parameter)
        {
            throw new NotImplementedException();
        }

        public void Execute(object parameter)
        {
            throw new NotImplementedException();
        }
    }
}