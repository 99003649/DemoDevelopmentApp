﻿using System.Windows;

namespace DemoDevelopmentApp.Views
{
    public partial class DevelopmentSupport : Window
    {
        public DevelopmentSupport()
        {
            InitializeComponent();
            DataContext = new ViewModels.DevelopmentSupportViewModel();
        }
    }
}
