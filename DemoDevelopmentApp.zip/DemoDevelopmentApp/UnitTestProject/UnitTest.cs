﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using DemoDevelopmentApp.ViewModels;
using DemoDevelopmentApp.Model;

namespace UnitTestProject
{
    [TestClass]
    public class UnitTest
    {
        [TestMethod]
        public void ExeNames()
        {
            //Arrange
            DevelopmentModel Obj = new DevelopmentModel();
            Obj.ExeName = "Calculator";
            //Act 
            string expected = "Calculator";
            string actual = Obj.ExeName;
            //Assert
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void KillProcess()
        {
            try
            {
                DevelopmentSupportViewModel Log = new DevelopmentSupportViewModel();
                Log.KillProcess(null);
                Assert.IsTrue(true);
            }
            catch
            {
                Assert.IsTrue(false);
            }
        }
        [TestMethod]
        public void ReplaceFile()
        {
            try
            {
                DevelopmentSupportViewModel Log = new DevelopmentSupportViewModel();
                Log.tbxFileSource = "C:\\Users\\nisha\\Documents\\Source";
                Log.tbxFileDest = "C:\\Users\\nisha\\Documents\\Destination";
                Log.ReplaceFile(null);
                Assert.IsTrue(true);
            }
            catch
            {
                Assert.IsTrue(false);
            }
        }
        [TestMethod]
        public void ClearCache()
        {
            try
            {
                DevelopmentSupportViewModel Log = new DevelopmentSupportViewModel();
                Log.ClearCache(null);
                Assert.IsTrue(true);
            }
            catch
            {
                Assert.IsTrue(false);
            }
        }
        [TestMethod]
        public void PDVCache()
        {
            try
            {
                DevelopmentSupportViewModel Log = new DevelopmentSupportViewModel();
                Log.tbxFileSource = "C:\\Users\\nisha\\Documents\\pdv\\products\\sciexos\\Source\\packages";
                Log.PDVCache(null);
                Assert.IsTrue(true);
            }
            catch
            {
                Assert.IsTrue(false);
            }
        }
        [TestMethod]
        public void OpenFileSource()
        {
            try
            {
                DevelopmentSupportViewModel Log = new DevelopmentSupportViewModel();
                Log.OpenFileSource(null);
                Assert.IsTrue(true);
            }
            catch
            {
                Assert.IsTrue(false);
            }
        }
        [TestMethod]
        public void OpenFileDestination()
        {
            try
            {
                DevelopmentSupportViewModel Log = new DevelopmentSupportViewModel();
                Log.OpenFileDestination(null);
                Assert.IsTrue(true);
            }
            catch
            {
                Assert.IsTrue(false);
            }
        }
    }
}
